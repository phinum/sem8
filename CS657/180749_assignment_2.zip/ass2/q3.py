import os
import time
#from google.colab import drive
import tarfile
import re
import shutil
import string
from nltk import ngrams
from collections import defaultdict
from indicnlp.tokenize import indic_tokenize
import matplotlib.pyplot as plt

working_directory = os.getcwd()
path_to_zip_file = os.path.join(working_directory,'hi.tar.xz')

#shutil.unpack_archive(path_to_zip_file, working_directory)
data_file = 'hi/hi.txt'

import pickle
with open('unique_words.pkl', 'rb') as f:
    unique_words = pickle.load(f)
unique_words = unique_words[0]

print(1) 

def char_n_gram(n, unique_words):
  top_100 = defaultdict()
  freq = defaultdict()
  cnt = 0
  for word in unique_words.keys():
    if not word.strip() or len(word) < n-1:
      continue
    if cnt%1000000==0:
      print("Line no {}".format(cnt))
    cnt+=1 
    try:
      n_grams = list(ngrams(word,n=n))
    except:
      print("error for word {}".format(word))
      continue
    if not n_grams:
      continue
    n_gram = ["".join(k1) for k1 in n_grams]
    for grams in n_gram:
      freq[grams] = freq.get(grams,0) + unique_words[word]
      top_100[grams] = freq[grams]
      if len(top_100.keys()) > 100:
        top_100_list = sorted(top_100.items(), key = lambda kv:kv[1])
        top_100_list.remove(top_100_list[0])
        top_100 = dict(top_100_list)
  return freq, sorted(top_100.items(), key = lambda kv:kv[1]) 

print(2)

if os.path.isfile('char.pkl'):
  with open('char.pkl', 'rb') as f:
    a, unig_top_100, b, big_top_100, c, trig_top_100, d, quadg_top_100 = pickle.load(f)
else:
  char_uni_freq, unig_top_100 = char_n_gram(1, unique_words)
  char_bi_freq, big_top_100 = char_n_gram(2, unique_words)
  char_tri_freq, trig_top_100 = char_n_gram(3, unique_words)
  char_quad_freq, quadg_top_100 = char_n_gram(4, unique_words)

print(3)

def syllabify(inputtext):
  vowels = '\u0904-\u0914\u0960-\u0961\u0972-\u0977' 
  consonants = '\u0915-\u0939\u0958-\u095F\u0978-\u097C\u097E-\u097F' 
  glottal = '\u097D' 
  vowel_signs = '\u093E-\u094C\u093A-\u093B\u094E-\u094F\u0955-\u0957\u1CF8-\u1CF9' 
  nasals = '\u0900-\u0902\u1CF2-\u1CF6' 
  visarga = '\u0903' 
  nukta = '\u093C' 
  avagraha = '\u093D' 
  virama = '\u094D' 
  vedic_signs = '\u0951-\u0952\u1CD0-\u1CE1\u1CED\u094D' 
  visarga_modifiers = '\u1CE2-\u1CE8' 
  combining = '\uA8E0-\uA8F1' 
  om = '\u0950' 
  accents = '\u0953-\u0954' 
  dandas = '\u0964-\u0965' 
  digits = '\u0966-\u096F\u0030-\u0039' 
  abbreviation = '\u0970' 
  spacing = '\u0971' 
  vedic_nasals = '\uA8F2-\uA8F7\u1CE9-\u1CEC\u1CEE-\u1CF1' 
  fillers = '\uA8F8-\uA8F9' 
  caret = '\uA8FA' 
  headstroke = '\uA8FB' 
  space = '\u0020' 
  joiners = '\u200C-\u200D'
  syllables = []
  curr = '' 
  # iterate over each character in the input. if a char belongs to a 
  # class that can be part of a syllable, then add it to the curr 
  # buffer. otherwise, output it to syllables[] right away. 
  for char in inputtext: 
    if re.match('[' + vowels + avagraha + glottal + om + ']', char): 
      # need to handle non-initial independent vowel letters, 
      # avagraha, and om
      if curr != '': 
        syllables.append(curr) 
        curr = char 
      else: 
        curr = curr + char
    elif re.match('[' + consonants + ']', char): 
      # if last in curr is not virama, output curr as syllable 
      # else add present consonant to curr
      if len(curr) > 0 and curr[-1] != virama:
        syllables.append(curr) 
        curr = char 
      else: 
        curr = curr + char
    elif re.match('[' + vowel_signs + visarga + vedic_signs + ']', char): 
      curr = curr + char
    elif re.match('[' + visarga_modifiers + ']', char): 
      if len(curr) > 0 and curr[-1] == visarga: 
        curr = curr + char 
        syllables.append(curr) 
        curr = '' 
      else: 
        syllables.append(curr) 
        curr = '' 
    elif re.match('[' + nasals + vedic_nasals + ']', char): 
      # if last in curr is a vowel sign, output curr as syllable 
      # else add present vowel modifier to curr and output as syllable 
      vowelsign = re.match('[' + vowel_signs + ']$', curr) 
      if vowelsign: 
        syllables.append(curr) 
        curr = '' 
      else: 
        curr = curr + char 
        syllables.append(curr) 
        curr = '' 
    elif re.match('[' + nukta + ']', char): 
      curr = curr + char 
    elif re.match('[' + virama + ']', char): 
      curr = curr + char 
    elif re.match('[' + digits + ']', char): 
      curr = curr + char 
    elif re.match('[' + fillers + headstroke + ']', char): 
      syllables.append(char) 
    elif re.match('[' + joiners + ']', char): 
      curr = curr + char 
    else:
      pass 
    # handle remaining curr 
  if curr != '': 
    syllables.append(curr) 
    curr = '' 
  return syllables
  # return each syllable as item in a list return syllables

print(4)

def syllables_n_gram(n, unique_words):
  top_100 = defaultdict()
  freq = defaultdict()
  cnt = 0
  for word in unique_words.keys():
    if cnt%1000000==0:
      print("Line no {}".format(cnt))
    cnt+=1
    syllables = syllabify(word)
    if not syllables or len(syllables) < n-1:
      continue
    n_gram = ngrams(syllables,n)
    try:
      for grams in n_gram:
        freq[grams] = freq.get(grams,0) + unique_words[word]
        top_100[grams] = freq[grams]
        if len(top_100.keys()) > 100:
          top_100_list = sorted(top_100.items(), key = lambda kv:kv[1])
          top_100_list.remove(top_100_list[0])
          top_100 = dict(top_100_list)
    except:
      print("Some issue encountered for word {}".format(word))
      continue
  return freq, sorted(top_100.items(), key = lambda kv:kv[1]) 

print(5)


if os.path.isfile('syllable.pkl'):
  with open('syllable.pkl', 'rb') as f:
    a, unisyl_top_100, b, bisyl_top_100, c, trisyl_top_100, d, quadsyl_top_100 = pickle.load(f)
else:
  emp = ""
  tmp = syllables_n_gram(1, unique_words)
  syll_uni_freq, unisyl_top_100 = [(emp.join(i[0]), i[1]) for i in tmp[0].items()], [(emp.join(i[0]), i[1]) for i in tmp[1]]
  tmp = syllables_n_gram(2, unique_words)
  syll_bi_freq, bisyl_top_100 = [(emp.join(i[0]), i[1]) for i in tmp[0].items()], [(emp.join(i[0]), i[1]) for i in tmp[1]]
  tmp = syllables_n_gram(3, unique_words)
  syll_tri_freq, trisyl_top_100 = [(emp.join(i[0]), i[1]) for i in tmp[0].items()], [(emp.join(i[0]), i[1]) for i in tmp[1]]
  tmp = syllables_n_gram(4, unique_words)
  syll_quad_freq, quadsyl_top_100 = [(emp.join(i[0]), i[1]) for i in tmp[0].items()], [(emp.join(i[0]), i[1]) for i in tmp[1]]

print(6)

def word_n_grams(n, data_file):
  top_100 = defaultdict()
  freq = defaultdict()
  cnt = 0
  prev = []
  table = str.maketrans(dict.fromkeys(string.punctuation))
  with open(data_file) as myfile:
    for line in myfile:
      if cnt%1000000==0:
        print("Line no {}".format(cnt))
      sentence = line.strip()
      cnt+=1
      s = sentence.translate(table)
      tokens = indic_tokenize.trivial_tokenize(s)
      if n == 3 or n == 2:
        if n == 2:
          if prev:
            tokens.insert(0,prev[-1])
        if n == 3:
          if prev:
            tokens.insert(0,prev[-1])
            if len(prev) >=2:
              tokens.insert(0,prev[-2])
        n_gram = ngrams(tokens,n)
        if len(tokens) < n-1:
          continue
      try:
        for grams in n_gram:
          if n == 1 or n==2 or n == 3:
            freq[grams] = freq.get(grams,0) + 1
            top_100[grams] = freq[grams]
            if len(top_100.keys()) > 100:
              top_100_list = sorted(top_100.items(), key = lambda kv:kv[1])
              top_100_list.remove(top_100_list[0])
              top_100 = dict(top_100_list)
      except:
        print("Error im {}".format(n_gram))
        continue
      prev = tokens
  return freq, sorted(top_100.items(), key = lambda kv:kv[1])

unigram_top_100 = sorted(unique_words.items(), key = lambda kv:kv[1])[-100:]
#_, bigram_top_100 = word_n_grams(2, data_file) 
#_, trigram_top_100 = word_n_grams(3, data_file)

for i in range(99, -1, -1):
  print(unig_top_100[i][0])
for i in range(99, -1, -1):
  print(big_top_100[i][0])
for i in range(99, -1, -1):
  print(trig_top_100[i][0])
for i in range(99, -1, -1):
  print(quadg_top_100[i][0])

for i in range(99, -1, -1):
  print(unisyl_top_100[i][0])
for i in range(99, -1, -1):
  print(bisyl_top_100[i][0])
for i in range(99, -1, -1):
  print(trisyl_top_100[i][0])
for i in range(99, -1, -1):
  print(quadsyl_top_100[i][0])

for i in range(99, -1, -1):
  print(unigram_top_100[i][0])

all_data = [unig_top_100, big_top_100, trig_top_100, quadg_top_100, unisyl_top_100, bisyl_top_100, trisyl_top_100, quadsyl_top_100, unigram_top_100]
cnt = 0
ind = 0
for data in all_data:
  cnt = cnt+1
  ind = ind+1
  if cnt > 4:
    which = 'syllables'
  elif cnt <=4:
    which = 'characters'
  else:
    which = 'words'
  if not isinstance(data, str):
    counts = [i[1] for i in data]
    tokens = [i[0] for i in data]
    rank = [i for i in range(101,1,-1)]
    multiplication = [counts[i] * rank[i] for i in range (len(counts))]
    plt.xlabel("Frequency Rank for the {}_gram of {}".format(ind%5,which))
    plt.ylabel("Frequency of Token for {}_gram for {}".format(ind%5, which))
    plt.plot(rank, counts)
    plt.savefig('{}_{}_grams.png'.format(which,ind%5))
    plt.show()
