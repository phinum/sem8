from transformers import AutoModel, AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained('ai4bharat/indic-bert')
model = AutoModel.from_pretrained('ai4bharat/indic-bert',output_hidden_states=True)

import numpy as np
import pandas as pd
import sys
import time
import pickle
from io import BytesIO
import re
import math
import sklearn
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
import spacy
import torch
from torch import Tensor
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Linear, Dropout,Softmax, ReLU, Module, CrossEntropyLoss
from torch.optim import SGD, Adam
from torch.utils.data import Dataset, DataLoader, random_split
from sklearn.utils import shuffle

print("Cuda available: {}".format(torch.cuda.is_available()))

device = torch.device('cpu') # use 'cuda' if gpu is available
print("Device is: {}".format(device))

'''
with open("hindi_ner/hi_train.conll", "r", encoding="utf8") as data:
    data = data.read()
    ini_data = data.split("\n")

word = []
token = []
for i in range(len(ini_data)):
  if ini_data[i] == '':
    continue
  x = ini_data[i].split(' ')
  if x[0] != '#':
    word.append(x[0])
    token.append(x[-1])

df = pd.DataFrame()
df['word'] = word 
df['token'] = token
df = df[df['token'] != 'O']
df = df.reset_index(drop=True)

emb = []
for i in range(len(df)):
  if i%1000 == 0:
    print(i)
  input_encoded = tokenizer.encode_plus(df['word'][i], return_tensors="pt")
  #print(df['word'][i])
  #print(input_encoded)
  with torch.no_grad():
         states = model(**input_encoded).hidden_states
  #print(states)
  output = torch.stack([states[i] for i in range(len(states))])
  #print(output.shape)
  output = output.squeeze()
  sum_tensor = torch.zeros(768)
  n = 0
  for i in range(len(output)):
    for j in range(len(output[i])):
      n = n+1
      sum_tensor = sum_tensor + output[i][j]
      
  sum_tensor = sum_tensor/n
  emb.append(sum_tensor)
emb = np.array(emb)
np.save('train.npy', emb, allow_pickle=True)
'''

df_train = pd.read_csv("train_data.csv")
df_dev = pd.read_csv("dev_data.csv")

test = np.load('dev_data.npy', allow_pickle=True)
arr_test = []
for i in range(len(test)):
  arr_test.append(test[i].numpy())
arr_test = np.array(arr_test)
print(arr_test.shape)

train_tensor = np.load('train_data.npy', allow_pickle=True)
train_tensor.shape[0]

temp_array = []
for i in range(35021):
  temp_array.append(train_tensor[i].numpy())
temp_array = np.array(temp_array)
print(temp_array.shape)

ner_label = {'B-CORP': 0,
 'B-CW': 1,
 'B-GRP': 2,
 'B-LOC': 3,
 'B-PER': 4,
 'B-PROD': 5,
 'I-CORP': 6,
 'I-CW': 7,
 'I-GRP': 8,
 'I-LOC': 9,
 'I-PER': 10,
 'I-PROD': 11}


df_train['label'] = df_train['token'].apply(lambda x: ner_label[x])
df_dev['label'] = df_dev['token'].apply(lambda x: ner_label[x])

df_train

class Train_data():

    def __init__(self,df):
        embeddings = temp_array
        scaler = StandardScaler()
        scaled_embeddings = scaler.fit_transform(embeddings)
        labels = np.array(df['label'])
        self.x = torch.from_numpy(scaled_embeddings)
        self.y = torch.from_numpy(labels)
        self.n_samples = len(labels)

    def __getitem__(self, index):
        return self.x[index], self.y[index]

    def __len__(self):
        return self.n_samples

class Dev_data():

    def __init__(self,df):
        embeddings = arr_test
        #scaler = pickle.load(open('/content/NER_pytorch_scaler','rb'))
        scaler = StandardScaler()
        scaled_embeddings = scaler.fit_transform(embeddings)
        #pickle.dump(scaler,open('NER'+'_pytorch_scaler','wb'))
        labels = np.array(df['label'])
        self.x = torch.from_numpy(scaled_embeddings)

        self.y = torch.from_numpy(labels)
        self.n_samples = len(labels)

    def __getitem__(self, index):
        return self.x[index], self.y[index]

    def __len__(self):
        return self.n_samples

class Network(nn.Module):
    def __init__(self,n_inputs,df_length):
        super().__init__()
        #self.hidden1 = nn.LSTM(n_inputs,1024)
        #self.hidden2 = nn.LSTM(1024,512)
        #self.hidden3 = nn.Linear(512,256)
        #self.hidden3 = nn.LSTM(256,df_length)
        #self.dropout = nn.Dropout(0.25)
        self.lstm = nn.LSTM(n_inputs, 1024, 1, batch_first=True) #lstm
        self.fc_1 =  nn.Linear(1024, 128) #fully connected 1
        self.fc = nn.Linear(128, df_length) #fully connected last layer
        self.relu = nn.ReLU()

    def forward(self, x):
        #X = F.relu(self.hidden1(X))
        #X = self.dropout(X)
        #X = F.relu(self.hidden2(X))
        #X = self.dropout(X)
        #X = F.relu(self.hidden3(X))
        #X = self.dropout(X)
       # X = self.hidden3(X)
        #X = F.log_softmax(X,dim=1)
       # return X

        #h_0 = Variable(torch.zeros(self.num_layers, X.size(0), self.hidden_size)) #hidden state
        #c_0 = Variable(torch.zeros(self.num_layers, X.size(0), self.hidden_size)) #internal state
        # Propagate input through LSTM
        output, (hn, cn) = self.lstm(x) #lstm with input, hidden, and internal state
        hn = hn.view(-1, 1024) #reshaping the data for Dense layer next
        out = self.relu(hn)
        out = self.fc_1(out) #first Dense
        out = self.relu(out) #relu
        out = self.fc(out) #Final Output
        return out
 

train = Train_data(df_train)
train_dl = DataLoader(train, batch_size=256,shuffle=True)
num_epochs = 300
input = 768
df_length = len(set(list(df_train['token'])))
model = Network(input,df_length)
model = model.to(device)
criterion = CrossEntropyLoss()
optimizer = Adam(model.parameters(),lr=0.0001)
model.train()

overall_time = 0
for epoch in range(num_epochs):
    start = time.time()
    model.train()
    batch_loss = 0
    for i, (inputs, targets) in enumerate(train_dl):
        inputs, targets = inputs.to(device), targets.to(device)
        #print(inputs)
        #print(targets)
        inputs.unsqueeze_(-2)
        #print(inputs.shape)
        optimizer.zero_grad()
        yhat = model(inputs)
        loss = criterion(yhat,targets)
        loss.backward()
        optimizer.step()
        batch_loss += loss
    overall_time += (time.time()-start)
    print("Epoch: {}, Time: {}, Loss: {}".format(epoch+1,time.time()-start,batch_loss/len(train_dl)))

print("Training Finished.")
overall_time += (time.time()-start)
print("Time taken for Training: {} mins".format(overall_time/60))
#torch.save(model.state_dict(),'NER' + '_pytorch_model.pt')

def evaluate_model(test_dl, model):
  predictions, actuals = list(), list()
  model.eval()
  for i, (inputs, targets) in enumerate(test_dl):
      inputs, targets = inputs.to(device), targets.to(device)
      inputs.unsqueeze_(-2)
      with torch.no_grad():
          yhat = model(inputs)
      yhat = yhat.cpu().detach().numpy()
      actual = targets.cpu().numpy()
      yhat = np.argmax(yhat, axis=1)
      actual = actual.reshape((len(actual), 1))
      yhat = yhat.reshape((len(yhat), 1))
      predictions.append(yhat)
      actuals.append(actual)
  predictions, actuals = np.vstack(predictions), np.vstack(actuals)
  f1 = f1_score(actuals, predictions, average='micro')
  return f1

test = Dev_data(df_dev)
print(test)

test_dl = DataLoader(test, batch_size=64,shuffle=True)

train_acc = evaluate_model(train_dl,model)
print("Training Accuracy: {} %".format(train_acc*100))

train_acc = evaluate_model(test_dl,model)
print("Test Accuracy: {} %".format(train_acc*100))
