import os
from gensim.scripts.glove2word2vec import glove2word2vec
import numpy as np
import csv
from gensim.models import KeyedVectors
from gensim.models import Word2Vec
working_directory = os.getcwd()

def dim_50(n):
  cbow_path_model = os.path.join(working_directory,'50/cbow/hi-d50-m2-cbow.model')
  skip_path_model = os.path.join(working_directory,'50/sg/hi-d50-m2-sg.model')
  fasttext_path_model = os.path.join(working_directory,'50/fasttext/hi-d50-m2-fasttext.model')
  glove_input_file = os.path.join(working_directory,'50/glove/hi-d50-glove.txt')
  word2vec_output_file = 'word2vec_50.txt'
  if n == 1:
    return Word2Vec.load(cbow_path_model)
  elif n == 2:
    return Word2Vec.load(skip_path_model)
  elif n == 3:
    return Word2Vec.load(fasttext_path_model)
  else:
    embedding_dict = {}
    try:
      with open(glove_input_file, 'r') as myfile:
        for line in myfile:
          line = str(line)
          lis = line.strip().split(' ')
          word, embeddings = lis[0], np.array([float(x) for x in lis[1:]], dtype=np.float64)
          embedding_dict[word] = embeddings
    except:
      print("some issue")
    return embedding_dict

def dim_100(n):
  cbow_path_model = os.path.join(working_directory,'100/cbow/hi-d100-m2-cbow.model')
  skip_path_model = os.path.join(working_directory,'100/sg/hi-d100-m2-sg.model')
  fasttext_path_model = os.path.join(working_directory,'100/fasttext/hi-d100-m2-fasttext.model')
  glove_input_file = os.path.join(working_directory,'100/glove/hi-d100-glove.txt')
  word2vec_output_file = 'word2vec_100.txt'
  if n == 1:
    return Word2Vec.load(cbow_path_model)
  elif n == 2:
    return Word2Vec.load(skip_path_model)
  elif n == 3:
    return Word2Vec.load(fasttext_path_model)
  else:
    embedding_dict = {}
    try:
      with open(glove_input_file, 'r') as myfile:
        for line in myfile:
          line = str(line)
          lis = line.strip().split(' ')
          word, embeddings = lis[0], np.array([float(x) for x in lis[1:]], dtype=np.float64)
          embedding_dict[word] = embeddings
    except:
      print("some issue")
    return embedding_dict
    

def word_similarity(mod_num):
  filenames = ['cbow','skipgram','fasttext','glove']
  dims = ['50','100']
  s = [0.4,0.5,0.6,0.7,0.8]
  for j in range(1,2): #for j in range(1,3):
    #print("Loading Model_{} for {} dimensions for threshold of {}..........".format(filenames[mod_num-1],dims[j-1], thresh))
    if j == 1:
      model = dim_50(mod_num)
    else:
      model = dim_100(mod_num)
    print("{} for {} dimensions Loaded...............".format(filenames[mod_num-1],dims[j-1]))
    for thresh in s:
      thresh = thresh*10
      if mod_num == 4:
        vocab = model.keys()
      else:
        vocab = model.wv.index_to_key
        #################################
        #If gensim 3.8 available
        #vocab = model.wv.vocab
      simi_file = os.path.join(working_directory, 'hindi.txt')
      correct = 0
      fields = ['w1','w2','cosine','ground','similar']
      filename = 'Q1_'+ filenames[mod_num-1] + '_similarity_' + '{}_'.format(thresh) + dims[j-1] + "_dimensions.csv"
      with open(filename, 'w', encoding = 'utf-8', errors='ignore') as csvfile: 
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(fields)
        with open(simi_file) as f:
          cnt = 0
          for line in f:
            if not line.strip():
              continue
            cnt+=1
            print("Word Pair Number {}".format(cnt))
            w1, w2, anno = line.split(',')
            anno = float(anno)
            if mod_num!=4:
              w1_vec = model.wv[w1] if w1 in vocab else (np.zeros(50) if j==0 else np.zeros(100))
              w2_vec = model.wv[w2] if w2 in vocab else (np.zeros(50) if j==0 else np.zeros(100))
            else:
              w1_vec = model[w1] if w1 in vocab else (np.zeros(50) if j==0 else np.zeros(100))
              w2_vec = model[w2] if w2 in vocab else (np.zeros(50) if j==0 else np.zeros(100))
            cosine = np.dot(w1_vec,w2_vec)
            if cosine!=0:
              cosine = 10 * (cosine/(np.linalg.norm(w1_vec) * np.linalg.norm(w2_vec)))
            row = [w1,w2,str(cosine),str(anno)]
            if anno > thresh:
              row.append('1')
            else:
              row.append('0')
            if (anno > thresh and cosine > thresh) or (anno <= thresh and cosine <= thresh):
              correct += 1
            csvwriter.writerow(row)
        accuracy = correct/cnt
        print(accuracy)
        csvwriter.writerow([str(accuracy)])

if __name__ == '__main__':
  word_similarity(1)
  word_similarity(2)
  word_similarity(3)
  word_similarity(4)



